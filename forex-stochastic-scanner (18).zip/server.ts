import express from 'express';
import path from 'path';
import cors from 'cors';
import yahooFinancePkg from 'yahoo-finance2';
import { createServer as createViteServer } from 'vite';
import { XMLParser } from 'fast-xml-parser';

const YFClass = (yahooFinancePkg as any).default || yahooFinancePkg;
const yahooFinance = new YFClass();
const app = express();
const PORT = 3000;

app.use((req, res, next) => {
  console.log(`[REQUEST] ${req.method} ${req.originalUrl}`);
  next();
});

app.use(cors());

// List of target pairs
const PAIRS = [
  'EURUSD=X', 'AUDUSD=X', 'GBPUSD=X', 'NZDUSD=X',
  'EURCAD=X', 'AUDCAD=X', 'GBPCAD=X', 'USDCHF=X', 'GBPCHF=X',
  'EURJPY=X', 'AUDJPY=X',
  'NQ=F'
];

let pricesCache: { data: Record<string, number>, timestamp: number } | null = null;
const PRICE_CACHE_DURATION = 10000; // 10 seconds

app.get('/api/prices', async (req, res) => {
  if (pricesCache && Date.now() - pricesCache.timestamp < PRICE_CACHE_DURATION) {
    return res.json(pricesCache.data);
  }

  try {
    const quotes = await yahooFinance.quote(PAIRS);
    const prices: Record<string, number> = {};
    
    quotes.forEach((q: any) => {
      let cleanSymbol = q.symbol.replace('=X', '');
      if (q.symbol === 'NQ=F') cleanSymbol = 'NASDAQ';
      if (q.regularMarketPrice) {
        prices[cleanSymbol] = q.regularMarketPrice;
      }
    });

    pricesCache = { data: prices, timestamp: Date.now() };
    res.json(prices);
  } catch (error: any) {
    console.error('Failed to fetch prices:', error.message || error);
    // Fallback to old cache if Yahoo rate limits us
    if (pricesCache) {
      return res.json(pricesCache.data);
    }
    res.status(500).json({ error: 'Failed to fetch prices' });
  }
});

/**
 * Calculates Smoothed Moving Average (SMMA)
 */
function calculateSMMA(data: number[], period: number): number[] {
  if (data.length < period) return [];
  const smma: number[] = [];
  
  // First value is Simple Moving Average (SMA)
  let sum = 0;
  for (let i = 0; i < period; i++) sum += data[i];
  smma.push(sum / period);

  // Subsequent values are smoothed
  for (let i = period; i < data.length; i++) {
    const prev = smma[smma.length - 1];
    const current = (prev * (period - 1) + data[i]) / period;
    smma.push(current);
  }
  return smma;
}

function calculateATR(quotes: any[], period: number): number {
  if (quotes.length < period + 1) return 0;
  const trs = [];
  for (let i = 1; i < quotes.length; i++) {
    const high = quotes[i].high;
    const low = quotes[i].low;
    const prevClose = quotes[i-1].close;
    if (high == null || low == null || prevClose == null) continue;
    const tr = Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose));
    trs.push(tr);
  }
  if (trs.length < period) return 0;
  const recentTrs = trs.slice(-period);
  return recentTrs.reduce((a, b) => a + b, 0) / period;
}

/**
 * Calculates Stochastic Oscillator with Custom Parameters
 * %K period = 8, %D period = 3, Slowing = 3
 * Price Field = Close/Close
 * Method = Smoothed
 */
function calculateStochastic(closes: number[], kPeriod: number, dPeriod: number, slowing: number) {
  const rawK: number[] = [];
  
  // Calculate Raw %K
  for (let i = kPeriod - 1; i < closes.length; i++) {
    const window = closes.slice(i - kPeriod + 1, i + 1);
    const hh = Math.max(...window);
    const ll = Math.min(...window);
    let k = 50; // Default to middle if no movement
    if (hh !== ll) {
      k = ((closes[i] - ll) / (hh - ll)) * 100;
    }
    rawK.push(k);
  }

  // Apply Slowing (SMMA to Raw %K) to get %K line
  const smoothedK = calculateSMMA(rawK, slowing);

  // Apply %D period (SMMA to %K line) to get %D line
  const dLine = calculateSMMA(smoothedK, dPeriod);

  if (smoothedK.length === 0 || dLine.length === 0) return null;

  return {
    k: smoothedK[smoothedK.length - 1],
    d: dLine[dLine.length - 1]
  };
}

let cachedNews: any[] = [];
let newsLastFetched = 0;

// Cache signals per timeframe
const signalCache: Record<string, { data: any, timestamp: number }> = {};
const CACHE_DURATION = 2 * 60 * 1000; // 2 minutes

const countryCurrencyMap: Record<string, string> = {
  'United States': 'USD',
  'Canada': 'CAD',
  'Euro Area': 'EUR',
  'Germany': 'EUR',
  'France': 'EUR',
  'Spain': 'EUR',
  'Italy': 'EUR',
  'United Kingdom': 'GBP',
  'Japan': 'JPY',
  'Australia': 'AUD',
  'New Zealand': 'NZD',
  'Switzerland': 'CHF',
  'China': 'CNY',
};

async function getHighImpactNews() {
  const now = Date.now();
  if (now - newsLastFetched > 5 * 60 * 1000) { // 5 minutes cache
    newsLastFetched = now;
    try {
      const response = await fetch('https://www.myfxbook.com/rss/forex-economic-calendar-events', {
        headers: { 'User-Agent': 'Mozilla/5.0' }
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const text = await response.text();
      const parser = new XMLParser();
      const parsed = parser.parse(text);
      const items = parsed?.rss?.channel?.item;
      
      if (items && Array.isArray(items)) {
        const formattedNews = items.map((item: any) => {
          let desc = item.description.replace(/&#60;/g, '<').replace(/&#62;/g, '>').replace(/&#39;/g, "'").replace(/&#34;/g, '"');
          const tdRegex = /<td[^>]*>(.*?)<\/td>/gs;
          const tds = [...desc.matchAll(tdRegex)].map(m => m[1].trim());
          
          let impact = "Low";
          if (desc.includes('sprite-high-impact')) impact = "High";
          else if (desc.includes('sprite-medium-impact')) impact = "Medium";
          
          let previous = "", forecast = "", actual = "";
          if (tds.length >= 5) {
            previous = tds[2].replace(/<\/?[^>]+(>|$)/g, "").trim();
            forecast = tds[3].replace(/<\/?[^>]+(>|$)/g, "").trim();
            actual = tds[4].replace(/<\/?[^>]+(>|$)/g, "").trim();
          }
          
          let country: string | null = null;
          for (const [cName, curr] of Object.entries(countryCurrencyMap)) {
            if (item.title.startsWith(cName)) {
              country = curr;
              break;
            }
          }
          
          if (!country) return null;

          return {
            title: item.title,
            country,
            date: new Date(item.pubDate).toISOString(),
            impact,
            forecast,
            previous,
            actual: actual === "" ? undefined : actual
          };
        }).filter(Boolean);
        
        cachedNews = formattedNews.filter((n: any) => n.impact === 'High');
      }
    } catch (e: any) {
      console.error('Failed to fetch or parse news from MyFxBook:', e.message);
      // Return existing cached news if available, otherwise return empty array
      if (!cachedNews) {
        cachedNews = [];
      }
    }
  }
  return cachedNews;
}

function checkNewsLock(pair: string, newsEvents: any[]) {
  const isNasdaq = pair === 'NASDAQ';
  const currenciesInPair = isNasdaq ? ['USD'] : [pair.substring(0, 3), pair.substring(3, 6)];
  const nowMs = Date.now();

  let locked = false;
  let reason = null;
  let lockEndTime: number | null = null;
  let nextNewsTime: number | null = null;
  let nextNewsTitle: string | null = null;

  for (const event of newsEvents) {
    if (event.impact !== 'High') continue;

    const title = event.title.toLowerCase();
    
    let hoursBefore = 10;
    let hoursAfter = 6;
    let affectsPair = false;

    // TIER 1: 24 Jam sebelum, 8 Jam sesudah (Semua USD + NASDAQ)
    if (
      title.includes('fomc') || title.includes('federal funds rate') || 
      title.includes('nfp') || title.includes('non-farm') || title.includes('nonfarm') ||
      (title.includes('cpi') && event.country === 'USD') ||
      title.includes('core pce') ||
      title.includes('jackson hole') ||
      title.includes('warsh speaks') ||
      title.includes('payrolls revision')
    ) {
      if (currenciesInPair.includes('USD') || isNasdaq) {
        affectsPair = true;
        hoursBefore = 24;
        hoursAfter = 8;
      }
    }
    // TIER 3: 14 Jam sebelum, 4 Jam sesudah
    else if (
      title.includes('jobless claim') || 
      title.includes('retail sales') || 
      (title.includes('ppi') && event.country === 'USD')
    ) {
      if (currenciesInPair.includes('USD') || isNasdaq) {
        affectsPair = true;
        hoursBefore = 14;
        hoursAfter = 4;
      }
    } 
    else if (title.includes('jolt') || title.includes('ism pmi')) {
      if (['EURUSD', 'AUDUSD', 'GBPUSD', 'NASDAQ'].includes(pair)) {
        affectsPair = true;
        hoursBefore = 14;
        hoursAfter = 4;
      }
    }
    // TIER 2: 18 Jam sebelum, 6 Jam sesudah (Berita spesifik negara)
    else if (
      (title.includes('cpi') && ['AUD', 'GBP', 'EUR'].includes(event.country)) ||
      (title.includes('employment') && event.country === 'AUD') ||
      (title.includes('rate decision') && ['AUD', 'GBP', 'EUR'].includes(event.country)) ||
      title.includes('rba') || title.includes('boe') || title.includes('ecb') || title.includes('official bank rate') || title.includes('main refinancing rate')
    ) {
      if (currenciesInPair.includes(event.country)) {
        affectsPair = true;
        hoursBefore = 18;
        hoursAfter = 6;
      }
    }
    // Default fallback
    else {
      if (currenciesInPair.includes(event.country)) {
        affectsPair = true;
        hoursBefore = 10; // default
        hoursAfter = 6;
      } else if (event.country === 'CNY' && (currenciesInPair.includes('JPY') || currenciesInPair.includes('AUD') || currenciesInPair.includes('NZD'))) {
        affectsPair = true;
        hoursBefore = 10; // default
        hoursAfter = 6;
      }
    }

    if (affectsPair) {
      const eventTime = new Date(event.date).getTime();
      const lockStartTimeMs = eventTime - hoursBefore * 60 * 60 * 1000;
      const lockEndTimeMs = eventTime + hoursAfter * 60 * 60 * 1000;
      
      if (nowMs >= lockStartTimeMs && nowMs <= lockEndTimeMs) {
        locked = true;
        reason = `High impact news: ${event.title} (${event.country})`;
        if (!lockEndTime || lockEndTimeMs > lockEndTime) {
            lockEndTime = lockEndTimeMs;
        }
      }
      
      if (eventTime > nowMs) {
        if (!nextNewsTime || eventTime < nextNewsTime) {
            nextNewsTime = eventTime;
            nextNewsTitle = `${event.country}: ${event.title}`;
        }
      }
    }
  }

  return { locked, reason, lockEndTime, nextNewsTime, nextNewsTitle };
}

async function startServer() {
  app.get('/api/news', async (req, res) => {
    try {
      const newsEvents = await getHighImpactNews();
      res.json(newsEvents);
    } catch (error: any) {
      console.error('Error fetching news:', error);
      res.status(500).json({ error: 'Failed to fetch news data' });
    }
  });

  app.get('/api/signals', async (req, res) => {
    const { timeframe = '15m' } = req.query;
    
    // Check cache
    const cacheKey = String(timeframe);
    if (signalCache[cacheKey] && (Date.now() - signalCache[cacheKey].timestamp < CACHE_DURATION)) {
      console.log(`[CACHE HIT] Returning cached signals for timeframe: ${timeframe}`);
      return res.json(signalCache[cacheKey].data);
    }
    
    // Map to yahoo-finance intervals
    let interval: '15m' | '30m' | '60m' = '15m';
    let isH4 = false;
    if (timeframe === '30m') interval = '30m';
    if (timeframe === '1h') interval = '60m';
    if (timeframe === '4h') {
      interval = '60m';
      isH4 = true;
    }

    try {
      const newsEvents = await getHighImpactNews();

      // Fetch 20 days of data to ensure we have enough candles after downsampling
      const period1 = new Date(Date.now() - 20 * 24 * 60 * 60 * 1000);

      const promises = PAIRS.map(async (symbol) => {
        try {
          let pairClean = symbol.replace('=X', '');
          if (symbol === 'NQ=F') pairClean = 'NASDAQ';
          
          const newsLock = checkNewsLock(pairClean, newsEvents);
          
          const result = await yahooFinance.chart(symbol, {
            period1,
            interval: interval as any,
          });

          if (!result || !result.quotes || result.quotes.length === 0) return null;

          const quotesClean = result.quotes.filter((q: any) => q.high != null && q.low != null && q.close != null);
          const atr14 = calculateATR(quotesClean, 14);
          const atr50 = calculateATR(quotesClean, 50);
          const isVolatile = atr14 > atr50; // Simple check if current ATR is above average ATR
          
          // ATR Filter: only take signal if current ATR 14 is > 0.8 * previous ATR 14
          const prevAtr14 = calculateATR(quotesClean.slice(0, -1), 14);
          const hasSufficientVolatility = atr14 > (0.8 * prevAtr14);

          let closes = result.quotes.map((r: any) => r.close).filter((c: number | null) => c !== null) as number[];

          if (isH4) {
            // Downsample to 4H candles by taking every 4th 1H close backwards from the most recent
            const h4Closes = [];
            for (let i = closes.length - 1; i >= 0; i -= 4) {
              h4Closes.unshift(closes[i]);
            }
            closes = h4Closes;
          }

          const stoch = calculateStochastic(closes, 8, 3, 3);
          if (!stoch) return null;
          
          let signal = 'neutral';
          
          let overbought = 95;
          let oversold = 5;
          if (timeframe === '30m') {
            overbought = 96;
            oversold = 4;
          } else if (timeframe === '1h') {
            overbought = 97;
            oversold = 3;
          } else if (timeframe === '4h') {
            overbought = 98;
            oversold = 2;
          }

          // Only send signal if not locked by news AND passes ATR volatility filter
          if (!newsLock.locked && hasSufficientVolatility) {
            if (stoch.k <= oversold || stoch.d <= oversold) signal = 'buy';
            else if (stoch.k >= overbought || stoch.d >= overbought) signal = 'sell';
          }

          return {
            pair: pairClean,
            close: closes[closes.length - 1],
            k: stoch.k,
            d: stoch.d,
            signal,
            locked: newsLock.locked,
            lockReason: newsLock.reason,
            lockEndTime: newsLock.lockEndTime,
            nextNewsTime: newsLock.nextNewsTime,
            nextNewsTitle: newsLock.nextNewsTitle,
            isVolatile
          };
        } catch (err) {
          console.error(`Error fetching ${symbol}:`, err);
          return null;
        }
      });

      const results = (await Promise.all(promises)).filter(Boolean);
      
      // Update cache
      signalCache[cacheKey] = {
        data: results,
        timestamp: Date.now()
      };
      
      res.json(results);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to fetch data' });
    }
  });

  // Vite middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
