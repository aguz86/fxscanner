/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Dashboard } from './components/Dashboard';
import { ProfitCalculator } from './components/ProfitCalculator';
import { Calendar as CalendarTab } from './components/Calendar';
import { Rules as RulesTab } from './components/Rules';
import { Activity, Calculator, LogOut, Calendar as CalendarIcon, BookOpen } from 'lucide-react';
import { getMaintenanceState, getFridayNotifState } from './utils/maintenance';
import { MaintenanceScreen } from './components/MaintenanceScreen';
import { FridayNotif } from './components/FridayNotif';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  const [activeTab, setActiveTab] = useState<'scanner' | 'calculator' | 'calendar' | 'rules'>('scanner');
  const [metaquotesId, setMetaquotesId] = useState('2EB3A8DA');
  
  const [maintenance, setMaintenance] = useState<{ isMaintenance: boolean; targetTimeLocal: Date | null }>({
    isMaintenance: false,
    targetTimeLocal: null
  });
  const [isFridayNotif, setIsFridayNotif] = useState(false);

  useEffect(() => {
    setMaintenance(getMaintenanceState());
    setIsFridayNotif(getFridayNotifState());

    const interval = setInterval(() => {
      setMaintenance(getMaintenanceState());
      setIsFridayNotif(getFridayNotifState());
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const checkAuth = () => {
      const storedAuth = localStorage.getItem('fxScannerAuth');
      if (storedAuth) {
        try {
          const { username: storedUsername, expiresAt } = JSON.parse(storedAuth);
          if (Date.now() < expiresAt) {
            setUsername(storedUsername);
            setIsLoggedIn(true);
          } else {
            localStorage.removeItem('fxScannerAuth');
          }
        } catch (e) {
          localStorage.removeItem('fxScannerAuth');
        }
      }
      setIsCheckingAuth(false);
    };
    checkAuth();
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.toLowerCase() === 'jfx') {
      setIsLoggedIn(true);
      setError('');
      // Save for 30 days
      const expiresAt = Date.now() + 30 * 24 * 60 * 60 * 1000;
      localStorage.setItem('fxScannerAuth', JSON.stringify({ username, expiresAt }));
    } else {
      setError('Invalid username');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('fxScannerAuth');
    setIsLoggedIn(false);
    setUsername('');
  };

  if (maintenance.isMaintenance && maintenance.targetTimeLocal) {
    return <MaintenanceScreen targetTime={maintenance.targetTimeLocal} />;
  }

  if (isCheckingAuth) {
    return (
      <main className="min-h-screen bg-[#0A0A0A] flex items-center justify-center p-6">
        <div className="w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
      </main>
    );
  }

  if (!isLoggedIn) {
    return (
      <main className="min-h-screen bg-[#0A0A0A] flex flex-col items-center justify-center p-6 text-white font-sans">
        <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-8 shadow-2xl">
          <div className="mb-8 text-center">
            <h1 className="text-3xl font-extrabold tracking-tight mb-2">JFX Scanner</h1>
            <p className="text-neutral-400 text-sm">Please log in to access the dashboard.</p>
          </div>
          
          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label htmlFor="username" className="block text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">
                Username
              </label>
              <input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter username..."
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-3.5 text-white focus:outline-none focus:border-indigo-500 transition-colors"
                autoFocus
              />
            </div>
            
            {error && <p className="text-rose-500 text-sm font-medium">{error}</p>}
            
            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold tracking-wide uppercase py-3.5 rounded-xl transition-colors"
            >
              Access Dashboard
            </button>
          </form>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[#0A0A0A] text-white font-sans flex flex-col">
      <nav className="border-b border-neutral-800 bg-neutral-950 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-2 sm:px-4 md:px-8">
          <div className="flex flex-wrap items-center justify-between gap-y-3 py-3 md:h-16 md:py-0">
            {/* Logo */}
            <div className="flex items-center gap-2 order-1">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#0277bd] to-[#01579b] flex items-center justify-center font-black italic text-white tracking-tighter text-sm flex-shrink-0">
                J<span className="text-[#ffc107]">FX</span>
              </div>
              <span className="font-bold tracking-wide hidden sm:block">Scanner</span>
            </div>
            
            {/* Navigation Tabs */}
            <div className="flex items-center gap-1 sm:gap-2 overflow-x-auto no-scrollbar w-full md:w-auto order-3 md:order-2 justify-start md:justify-center pb-1 md:pb-0">
              <button
                onClick={() => setActiveTab('scanner')}
                className={`flex flex-shrink-0 items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${
                  activeTab === 'scanner'
                    ? 'bg-indigo-500/10 text-indigo-400'
                    : 'text-neutral-400 hover:bg-neutral-900 hover:text-neutral-300'
                }`}
              >
                <Activity size={18} />
                <span className="inline">Scanner</span>
              </button>
              <button
                onClick={() => setActiveTab('calculator')}
                className={`flex flex-shrink-0 items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${
                  activeTab === 'calculator'
                    ? 'bg-indigo-500/10 text-indigo-400'
                    : 'text-neutral-400 hover:bg-neutral-900 hover:text-neutral-300'
                }`}
              >
                <Calculator size={18} />
                <span className="inline">Calculator</span>
              </button>
              
              <button
                onClick={() => setActiveTab('calendar')}
                className={`flex flex-shrink-0 items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${
                  activeTab === 'calendar'
                    ? 'bg-indigo-500/10 text-indigo-400'
                    : 'text-neutral-400 hover:bg-neutral-900 hover:text-neutral-300'
                }`}
              >
                <CalendarIcon size={18} />
                <span className="inline">Kalendar</span>
              </button>
              
              <button
                onClick={() => setActiveTab('rules')}
                className={`flex flex-shrink-0 items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${
                  activeTab === 'rules'
                    ? 'bg-indigo-500/10 text-indigo-400'
                    : 'text-neutral-400 hover:bg-neutral-900 hover:text-neutral-300'
                }`}
              >
                <BookOpen size={18} />
                <span className="inline">Rule</span>
              </button>
            </div>

            {/* Right Controls */}
            <div className="flex items-center gap-1 sm:gap-3 order-2 md:order-3">
              <div className="flex items-center gap-1 sm:gap-2 bg-neutral-900 rounded-lg px-2 sm:px-3 py-1.5 border border-neutral-800 focus-within:border-indigo-500/50 transition-colors">
                <span className="text-xs text-neutral-400 font-semibold tracking-wider hidden sm:inline">MQID</span>
                <input 
                  type="text"
                  value={metaquotesId}
                  onChange={(e) => setMetaquotesId(e.target.value)}
                  className="bg-transparent border-none focus:outline-none text-white text-xs sm:text-sm w-16 sm:w-20 uppercase font-mono"
                  placeholder="ID"
                />
                <button
                  onClick={() => alert(`MQID saved: ${metaquotesId}`)}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] sm:text-xs font-bold px-2 py-1 rounded transition-colors"
                >
                  SAVE
                </button>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center justify-center w-8 h-8 sm:w-auto sm:h-auto sm:px-3 sm:py-2 rounded-xl text-neutral-400 hover:bg-neutral-900 hover:text-white transition-colors"
                title="Log Out"
              >
                <LogOut size={18} />
                <span className="hidden sm:inline text-sm font-semibold ml-2">Logout</span>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="flex-1">
        {activeTab === 'scanner' && <Dashboard metaquotesId={metaquotesId} />}
        {activeTab === 'calculator' && <ProfitCalculator currentRates={[]} />}
        {activeTab === 'calendar' && <CalendarTab />}
        {activeTab === 'rules' && <RulesTab />}
      </div>
      
      {isFridayNotif && <FridayNotif />}
    </main>
  );
}

